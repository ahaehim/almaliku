package com.example.ahaehim.listviewfragment;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class fraglistview extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fraglistview_layout, container, false);

        ListView listview = (ListView) view.findViewById(R.id.mylist);
        String[] items = new String[]{"Sholat Subuh", "Sholat Zuhur", "Sholat Ashar"};
        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, items);
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        getFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.container_frag,new Conten_1 ()).commit();
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                }
            }
        });
        return view;
    }

}
