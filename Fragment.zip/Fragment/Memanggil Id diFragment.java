'@ahaehim_coding'
-------------------
===========================================================

EditText name = (EditText) getView().findViewById(R.id.editText1);

----------------------------rekomendasi---------------------------------------------

imagebutton = (ImageButton) getActivity().findViewById(R.id.imagebutton1);

----------------------------------------------------------------------------
 - getActivity().getApplicationContext() -



