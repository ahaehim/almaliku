'@ahaehim_coding'
-------------------
package com.ohaehim.kuankdev.jumatberkah;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

//ahaehim

public class Konten extends android.support.v4.app.Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.konten_layout, container, false);

        // Penerapan ListView
        ListView listview =(ListView)view.findViewById(R.id.lisku);
        String[] items = new String[] {"Item 1", "Item 2", "Item 3"};
        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, items);
        listview.setAdapter(adapter);

        // Ketika Item di Klik
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){
                    case 0:
                        getFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.list,new F1()).commit();
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                }
            }
        });
        return view;
    }
}
