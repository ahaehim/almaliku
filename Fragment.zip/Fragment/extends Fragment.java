'@ahaehim_coding'
-------------------
Fragment Deklarasi
---------------------------01----------standart-------------------------------------
public class Konten extends android.support.v4.app.Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        return inflater.inflate(R.layout.konten_layout, container, false);
    }
}

---------------------------------02-------rekomendasi---------------------------------------

public class Fragment1 extends Fragment implements OnClickListener{
     @Override
     public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


      View v = inflater.inflate(R.layout.fragment1, container, false);

     ((Button) v.findViewById(R.id.btn_frag2)).setOnClickListener(this);

     return v;
     }

     
}

