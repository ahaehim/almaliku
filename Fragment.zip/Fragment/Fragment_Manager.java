'@ahaehim_coding' 
-------------------
   Fragment Manager
--------------------------------------------
       import android.app.Fragment;
       -----------------------------------

        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        Konten fragment = new Konten();
        fragmentTransaction.add(R.id.list, fragment);
        fragmentTransaction.commit();

 -------------------------------------------
        android.support.v4.app.Fragment
        ----------------------------------

        getSupportFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.Tempat_Fragment,new Konten_Fragment ()).commit();