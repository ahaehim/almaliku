package com.example.ahaehim.sqlliteku;


import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Tampilkan_listdb extends AppCompatActivity {
    SQLLite_Ahim myDB;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tampilkan_data_sqllite);

        ListView listView=(ListView)findViewById(R.id.list_view);
        myDB=new SQLLite_Ahim(this);

        ArrayList<String>thelist=new ArrayList<>();
        Cursor data=myDB.getAllData();

        if (data.getCount()==0){
            Toast.makeText(this, "Tidak Ada Konten", Toast.LENGTH_SHORT).show();
        }else {
            while (data.moveToNext()){
                thelist.add(data.getString(1));
                ListAdapter listadapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,thelist);
                listView.setAdapter(listadapter);
            }
        }
    }
}
